package com.fatfinger.keyboard;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FatFingerIME extends InputMethodService implements KeyboardView.Listener {

    private KeyboardView view;
    private Predictor predictor;
    private SharedPreferences prefs;
    private boolean passwordField;
    private ClipboardManager clipboard;
    private final ClipboardManager.OnPrimaryClipChangedListener clipListener = this::captureClip;

    @Override
    public void onCreate() {
        super.onCreate();
        predictor = new Predictor(this);
        prefs = getSharedPreferences("fatfinger", MODE_PRIVATE);
        clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override
    public void onDestroy() {
        if (clipboard != null) clipboard.removePrimaryClipChangedListener(clipListener);
        super.onDestroy();
    }

    private void captureClip() {
        if (!prefs.getBoolean("clipOn", true) || clipboard == null) return;
        try {
            if (!clipboard.hasPrimaryClip()) return;
            ClipDescription d = clipboard.getPrimaryClipDescription();
            if (d != null && d.getExtras() != null
                    && d.getExtras().getBoolean("android.content.extra.IS_SENSITIVE", false)) return;
            ClipData cd = clipboard.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) return;
            CharSequence t = cd.getItemAt(0).coerceToText(this);
            if (t == null) return;
            String str = t.toString().trim();
            if (str.isEmpty() || str.length() > 2000) return;
            Clips.add(prefs, str);
            if (view != null) view.setClips(Clips.load(prefs));
        } catch (RuntimeException e) {
            // clipboard not readable right now
        }
    }

    @Override
    public View onCreateInputView() {
        view = new KeyboardView(this);
        view.setListener(this);
        view.setClipEnabled(prefs.getBoolean("clipOn", true));
        view.setClips(Clips.load(prefs));
        updatePrediction();
        return view;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        int var = info.inputType & InputType.TYPE_MASK_VARIATION;
        passwordField = cls == InputType.TYPE_CLASS_TEXT
                && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD);
        if (view != null) {
            boolean numeric = cls == InputType.TYPE_CLASS_NUMBER
                    || cls == InputType.TYPE_CLASS_PHONE
                    || cls == InputType.TYPE_CLASS_DATETIME;
            view.setLayer(numeric ? 1 : 0);
            view.refreshTheme();
            view.resetShift();
            view.setClipEnabled(prefs.getBoolean("clipOn", true));
            view.setClips(Clips.load(prefs));
        }
        captureClip();
        updatePrediction();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                  int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        updatePrediction();
    }

    private Set<String> activeLangs() {
        Set<String> s = prefs.getStringSet("langs", null);
        if (s == null || s.isEmpty()) {
            s = new HashSet<>();
            s.add("en");
        }
        return s;
    }

    private String currentPrefix() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";
        CharSequence before = ic.getTextBeforeCursor(40, 0);
        if (before == null) return "";
        int i = before.length();
        while (i > 0 && isLetter(before.charAt(i - 1))) i--;
        return before.subSequence(i, before.length()).toString();
    }

    private boolean atSentenceStart() {
        if (passwordField) return false;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence before = ic.getTextBeforeCursor(8, 0);
        if (before == null || before.length() == 0) return true;
        String s = before.toString();
        if (s.endsWith("\n")) return true;
        return s.matches("(?s).*[.!?]\\s+");
    }

    private static boolean isLetter(char c) {
        return Character.isLetter(c);
    }

    private static String capitalize(String w) {
        return w.isEmpty() ? w : Character.toUpperCase(w.charAt(0)) + w.substring(1);
    }

    private void updatePrediction() {
        if (view == null) return;
        predictor.configure(activeLangs());
        view.setLangs(activeLangs());
        String typed = currentPrefix();
        String prefix = typed.toLowerCase();
        boolean cap = typed.isEmpty() && atSentenceStart();
        Predictor.Result r = predictor.predict(prefix);

        StringBuilder extras = new StringBuilder();
        Set<String> langs = activeLangs();
        if (langs.contains("tl") || langs.contains("es")) extras.append('ñ');

        boolean upper = !typed.isEmpty() ? Character.isUpperCase(typed.charAt(0)) : cap;
        List<String> sug = new ArrayList<>();
        for (String w : r.words) sug.add(upper ? capitalize(w) : w);

        float boost = prefs.getFloat("boost", 1f);
        boolean pct = prefs.getBoolean("showPct", true);
        Map<String, Integer> lcm = new HashMap<>();
        for (String code : Theme.LANG_CODES) lcm.put(code, Theme.langColor(prefs, code));
        view.setLangColors(lcm, prefs.getBoolean("langColor", true));
        view.setPrediction(r, cap, extras.toString(), sug, boost, pct);
    }

    private void learnCurrent() {
        if (passwordField) return;
        String w = currentPrefix();
        if (!w.isEmpty()) predictor.learn(w);
    }

    @Override
    public void onLetter(char c, boolean upper) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(String.valueOf(upper ? Character.toUpperCase(c) : c), 1);
        updatePrediction();
    }

    @Override
    public void onChar(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        learnCurrent();
        if (c == '\n') {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        } else {
            ic.commitText(String.valueOf(c), 1);
        }
        updatePrediction();
    }

    @Override
    public void onToggleLang(String code) {
        Set<String> s = new HashSet<>(activeLangs());
        if (s.contains(code)) s.remove(code); else s.add(code);
        if (s.isEmpty()) s.add("en");
        prefs.edit().putStringSet("langs", s).apply();
        updatePrediction();
    }

    @Override
    public void onPasteClip(String str) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        learnCurrent();
        ic.commitText(str, 1);
        updatePrediction();
    }

    @Override
    public void onDeleteClip(int index) {
        Clips.remove(prefs, index);
        if (view != null) view.setClips(Clips.load(prefs));
    }

    @Override
    public void onClearClips() {
        Clips.clear(prefs);
        if (view != null) view.setClips(Clips.load(prefs));
    }

    @Override
    public void onReplaceLast(String str) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.beginBatchEdit();
        ic.deleteSurroundingText(1, 0);
        ic.commitText(str, 1);
        ic.endBatchEdit();
        updatePrediction();
    }

    @Override
    public void onBackspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        updatePrediction();
    }

    @Override
    public void onSuggestion(String word) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.beginBatchEdit();
        String typed = currentPrefix();
        if (!typed.isEmpty()) ic.deleteSurroundingText(typed.length(), 0);
        ic.commitText(word + " ", 1);
        ic.endBatchEdit();
        if (!passwordField) predictor.learn(word);
        updatePrediction();
    }
}
