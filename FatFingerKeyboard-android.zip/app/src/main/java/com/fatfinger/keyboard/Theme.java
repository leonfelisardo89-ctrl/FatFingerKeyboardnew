package com.fatfinger.keyboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

/** Color presets plus an optional accent override, shared by the keyboard and the settings screen. */
final class Theme {
    static final String[] IDS = {"auto", "light", "dark", "midnight", "forest", "ocean", "rose", "lavender"};
    static final String[] NAMES = {"Match system", "Light", "Dark", "Midnight (black)", "Forest", "Ocean", "Rose", "Lavender"};
    static final int[] ACCENTS = {0xFFD9480F, 0xFFE03131, 0xFFD6336C, 0xFF7048E8,
            0xFF1C7ED6, 0xFF0CA678, 0xFF37B24D, 0xFFF59F00};

    // bg, key, text, accent, panel (order matches IDS minus "auto")
    private static final int[][] PALETTES = {
            {0xFFECEEF2, 0xFFDDE1E8, 0xFF181C24, 0xFFD9480F, 0xFFFFFFFF}, // light
            {0xFF12151B, 0xFF2B313C, 0xFFE8EBF0, 0xFFFF8A3D, 0xFF1B2029}, // dark
            {0xFF000000, 0xFF1C1C1E, 0xFFF2F2F7, 0xFF4DABF7, 0xFF0A0A0C}, // midnight
            {0xFF14231A, 0xFF25402D, 0xFFE6F2E8, 0xFF8CD97C, 0xFF1B3023}, // forest
            {0xFF0B1D2E, 0xFF183A57, 0xFFE3F1FB, 0xFF4DD0E1, 0xFF102A41}, // ocean
            {0xFFFBEFF2, 0xFFF3D5DD, 0xFF3A1822, 0xFFD6336C, 0xFFFFFFFF}, // rose
            {0xFFEFEBFA, 0xFFDAD2F3, 0xFF241B3D, 0xFF7048E8, 0xFFFFFFFF}, // lavender
    };

    static final String[] LANG_CODES = {"en", "tl", "es", "pt", "fr", "de", "id"};
    // English blue, Filipino green, Spanish red, Portuguese amber, French purple, German teal, Indonesian pink
    private static final int[] LANG_DEFAULTS = {0xFF1C7ED6, 0xFF37B24D, 0xFFE03131, 0xFFF59F00,
            0xFF7048E8, 0xFF0CA678, 0xFFD6336C};

    static int langColor(SharedPreferences p, String code) {
        int def = LANG_DEFAULTS[0];
        for (int i = 0; i < LANG_CODES.length; i++) if (LANG_CODES[i].equals(code)) def = LANG_DEFAULTS[i];
        return p.getInt("lc_" + code, def);
    }

    /** Readable text color to put on top of a background color. */
    static int onColor(int c) {
        return brightness(c) > 0.55f ? 0xFF14110D : 0xFFFFFFFF;
    }

    int bg, key, fg, hot, hotFg, panel;

    static Theme load(Context c, SharedPreferences p) {
        String id = p.getString("theme", "auto");
        int idx = -1;
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) idx = i;
        int pal;
        if (idx <= 0) {
            boolean night = (c.getResources().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            pal = night ? 1 : 0;
        } else {
            pal = idx - 1;
        }
        int[] v = PALETTES[pal];
        Theme t = new Theme();
        t.bg = v[0];
        t.key = v[1];
        t.fg = v[2];
        t.hot = v[3];
        t.panel = v[4];
        int accent = p.getInt("accent", 0);
        if (accent != 0) t.hot = accent;
        t.hotFg = onColor(t.hot);
        return t;
    }

    private static float brightness(int c) {
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        return (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
    }
}
