package com.fatfinger.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Next-letter model built from word frequency lists plus words the user types. */
public class Predictor {

    /** p[0..25] = a..z, p[26] = n with tilde. */
    public static class Result {
        public final float[] p = new float[27];
        public float pEnd;
        public final List<String> words = new ArrayList<>();
        /** Index into codes of the language that contributes most to each letter, or -1. */
        public final int[] letterLang = new int[27];
        /** Language index for each entry of words, or -1 for words you taught it. */
        public final int[] wordLang = new int[3];
        public List<String> codes = new ArrayList<>();

        public Result() {
            java.util.Arrays.fill(letterLang, -1);
            java.util.Arrays.fill(wordLang, -1);
        }
    }

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Map<String, String[]> cache = new HashMap<>();
    private final Set<String> known = new HashSet<>();
    private final Map<String, Integer> user = new HashMap<>();
    private String[] words = new String[0];
    private float[] wts = new float[0];
    private int[] wlang = new int[0];
    private List<String> codes = new ArrayList<>();
    private String langKey = "";

    public Predictor(Context c) {
        ctx = c.getApplicationContext();
        prefs = ctx.getSharedPreferences("fatfinger", Context.MODE_PRIVATE);
        for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
            if (e.getKey().startsWith("u_") && e.getValue() instanceof Integer) {
                user.put(e.getKey().substring(2), (Integer) e.getValue());
            }
        }
    }

    public void configure(Set<String> langs) {
        List<String> list = new ArrayList<>(langs);
        Collections.sort(list);
        String key = list.toString();
        if (key.equals(langKey)) return;
        langKey = key;
        codes = list;
        int nl = list.size();
        LinkedHashMap<String, float[]> m = new LinkedHashMap<>();
        for (int li = 0; li < nl; li++) {
            String[] ws = load(list.get(li));
            for (int i = 0; i < ws.length; i++) {
                float w = 1f / (i + 8);
                float[] a = m.get(ws[i]);
                if (a == null) {
                    a = new float[nl];
                    m.put(ws[i], a);
                }
                a[li] += w;
            }
        }
        words = new String[m.size()];
        wts = new float[m.size()];
        wlang = new int[m.size()];
        int i = 0;
        for (Map.Entry<String, float[]> e : m.entrySet()) {
            float[] a = e.getValue();
            float sum = 0;
            int best = 0;
            for (int li = 0; li < nl; li++) {
                sum += a[li];
                if (a[li] > a[best]) best = li;
            }
            words[i] = e.getKey();
            wts[i] = sum;
            wlang[i] = best;
            i++;
        }
        known.clear();
        known.addAll(m.keySet());
    }

    private String[] load(String lang) {
        String[] cached = cache.get(lang);
        if (cached != null) return cached;
        String[] arr = new String[0];
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(ctx.getAssets().open("words-" + lang + ".txt"), "UTF-8"))) {
            String line = br.readLine();
            if (line != null) arr = line.trim().split(" ");
        } catch (IOException e) {
            // leave empty
        }
        cache.put(lang, arr);
        return arr;
    }

    public void learn(String word) {
        String w = word.toLowerCase();
        if (w.length() < 2 || w.length() > 20) return;
        Integer old = user.get(w);
        int n = (old == null ? 0 : old) + 1;
        user.put(w, n);
        prefs.edit().putInt("u_" + w, n).apply();
    }

    public void forgetAll() {
        SharedPreferences.Editor ed = prefs.edit();
        for (String w : user.keySet()) ed.remove("u_" + w);
        ed.apply();
        user.clear();
    }

    private static int index(char c) {
        if (c == 'ñ') return 26;
        if (c >= 'a' && c <= 'z') return c - 'a';
        return -1;
    }

    public Result predict(String prefix) {
        Result r = new Result();
        r.codes = codes;
        int nl = Math.max(1, codes.size());
        float[] counts = new float[27];
        float[][] lc = new float[27][nl];
        float[] topW = new float[3];
        String[] topS = new String[3];
        int[] topL = {-1, -1, -1};
        float[] acc = new float[2]; // 0 = total, 1 = end-of-word weight
        int n = prefix.length();

        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (n > 0 && !w.startsWith(prefix)) continue;
            float wt = wts[i];
            Integer u = user.get(w);
            if (u != null) wt += u * 0.02f;
            take(w, wt, wlang[i], n, counts, lc, topW, topS, topL, acc);
        }
        for (Map.Entry<String, Integer> e : user.entrySet()) {
            String w = e.getKey();
            if (known.contains(w)) continue;
            if (n > 0 && !w.startsWith(prefix)) continue;
            take(w, e.getValue() * 0.02f, -1, n, counts, lc, topW, topS, topL, acc);
        }

        float total = acc[0];
        if (total > 0) {
            for (int i = 0; i < 27; i++) r.p[i] = counts[i] / total;
        }
        for (int i = 0; i < 27; i++) {
            int best = -1;
            float bw = 0;
            for (int li = 0; li < nl; li++) {
                if (lc[i][li] > bw) { bw = lc[i][li]; best = li; }
            }
            r.letterLang[i] = best;
        }
        r.pEnd = n == 0 ? 0f : (total > 0 ? acc[1] / total : 0.5f);
        for (int i = 0; i < 3; i++) {
            if (topS[i] != null) {
                r.wordLang[r.words.size()] = topL[i];
                r.words.add(topS[i]);
            }
        }
        return r;
    }

    private static void take(String w, float wt, int lang, int n, float[] counts, float[][] lc,
                             float[] topW, String[] topS, int[] topL, float[] acc) {
        acc[0] += wt;
        if (w.length() == n) {
            acc[1] += wt;
            return;
        }
        int idx = index(w.charAt(n));
        if (idx >= 0) {
            counts[idx] += wt;
            if (lang >= 0 && lang < lc[idx].length) lc[idx][lang] += wt;
        }
        // insert into top 3
        for (int i = 0; i < 3; i++) {
            if (topS[i] == null || wt > topW[i]) {
                for (int j = 2; j > i; j--) {
                    topW[j] = topW[j - 1];
                    topS[j] = topS[j - 1];
                    topL[j] = topL[j - 1];
                }
                topW[i] = wt;
                topS[i] = w;
                topL[i] = lang;
                break;
            }
        }
    }
}
