package com.fatfinger.keyboard;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Keyboard whose keys grow and shrink with the chance each letter comes next. */
public class KeyboardView extends View {

    public interface Listener {
        void onLetter(char c, boolean upper);
        void onChar(char c);
        void onBackspace();
        /** Replace the character just typed (used by long-press accent picker). */
        void onReplaceLast(String s);
        void onToggleLang(String code);
        void onPasteClip(String text);
        void onDeleteClip(int index);
        void onClearClips();
        void onSuggestion(String word);
    }

    private static final int T_LETTER = 0, T_BS = 1, T_COMMA = 2, T_SPACE = 3, T_DOT = 4, T_ENTER = 5,
            T_CHAR = 6, T_SYM = 7, T_ALT = 8, T_ABC = 9, T_CLEAR = 10, T_LANG = 11, T_SHIFT = 12;

    private static final String[][] LANGS = {
            {"en", "English"}, {"tl", "Filipino"}, {"es", "Español"}, {"pt", "Português"},
            {"fr", "Français"}, {"de", "Deutsch"}, {"id", "Bahasa Indonesia"}
    };

    private static class Key {
        int type;
        char ch;
        String code = "", label = "";
        int tint;
        float p;
        float weight;
        final RectF r = new RectF();
    }

    private final List<Key> keys = new ArrayList<>();
    private final RectF[] sugRects = new RectF[3];
    private String[] sugWords = {"", "", ""};
    private Predictor.Result res;
    private boolean cap;
    private String extras = "";
    private float boost = 1f;
    private boolean showPct = true;
    private Listener listener;
    private int layer = 0; // 0 letters, 1 numbers/symbols, 2 more symbols, 3 clipboard, 4 languages

    // toolbar, clipboard and language panels
    private final RectF[] toolRects = {new RectF(), new RectF()};
    private final RectF titleRect = new RectF();
    private final RectF content = new RectF();
    private final RectF rowRect = new RectF();
    private Set<String> activeLangs = new HashSet<>();
    private List<String> clips = new ArrayList<>();
    private boolean clipEnabled = true, panMoved;
    private float clipOffset, panDownX, panDownY, panStartOff;
    private int panId = -1;
    private int shiftMode; // 0 auto, 1 one-shot upper, 2 caps lock, 3 one-shot lower
    private long lastShiftTap;
    private Map<String, Integer> langColors = new HashMap<>();
    private boolean colorByLang = true;

    // long-press accent picker
    private static final String GENERAL_ACCENTS =
            "àáâãäåæāçćčďðèéêëēěìíîïłñńòóôõöøœřśšßťùúûüůýÿźżž";
    private String langKey = "";
    private boolean ntilde;
    private final Map<Character, List<Character>> variantMap = new HashMap<>();
    private boolean lpActive, popShown, lpCap;
    private char lpChar;
    private int lpId, popSel = -1;
    private float lpX, lpY, popKeyTop;
    private String[] popVariants = new String[0];
    private RectF[] popRects = new RectF[0];
    private RectF popPanel = new RectF();

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Key pressed;
    private final float density;

    private int cBg, cKey, cFn, cFg, cHot, cHotFg, cPanel;

    public KeyboardView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        refreshTheme();
        text.setTextAlign(Paint.Align.CENTER);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1.5f));
        stroke.setColor(cHot);
        text.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        for (int i = 0; i < 3; i++) sugRects[i] = new RectF();
        setHapticFeedbackEnabled(true);
    }

    public void setListener(Listener l) { listener = l; }

    public void refreshTheme() {
        Theme t = Theme.load(getContext(), getContext().getSharedPreferences("fatfinger", Context.MODE_PRIVATE));
        cBg = t.bg; cKey = t.key; cFg = t.fg; cHot = t.hot; cHotFg = t.hotFg; cPanel = t.panel;
        cFn = blend(cKey, cBg, 0.22f);
        stroke.setColor(cHot);
        invalidate();
    }

    public void setClips(List<String> l) {
        clips = new ArrayList<>(l);
        clipOffset = Math.max(0f, Math.min(clipOffset, maxClipOffset()));
        invalidate();
    }

    public void setLangColors(Map<String, Integer> m, boolean on) {
        langColors = new HashMap<>(m);
        colorByLang = on;
    }

    public void resetShift() {
        shiftMode = 0;
        invalidate();
    }

    private boolean isUpper() {
        return shiftMode == 1 || shiftMode == 2 || (shiftMode == 0 && cap);
    }

    private int tintFor(int li) {
        if (!colorByLang || res == null || li < 0 || li >= res.codes.size()) return 0;
        Integer c = langColors.get(res.codes.get(li));
        return c == null ? 0 : c;
    }

    private int tintOf(char c) {
        if (res == null) return 0;
        int i = c == 'ñ' ? 26 : c - 'a';
        if (i < 0 || i >= 27) return 0;
        return tintFor(res.letterLang[i]);
    }

    private int sugTint(int i) {
        if (res == null || i >= res.words.size()) return 0;
        return tintFor(res.wordLang[i]);
    }

    private int langColorOf(String code) {
        Integer c = langColors.get(code);
        return c == null ? cHot : c;
    }

    private void tapShift() {
        long now = System.currentTimeMillis();
        boolean dbl = now - lastShiftTap < 350;
        lastShiftTap = now;
        if (shiftMode == 2) shiftMode = 0;
        else if (dbl) shiftMode = 2;
        else if (shiftMode == 1) shiftMode = 0;
        else if (shiftMode == 0 && cap) shiftMode = 3;
        else shiftMode = 1;
        invalidate();
    }

    public void setClipEnabled(boolean on) {
        if (on != clipEnabled) { clipEnabled = on; invalidate(); }
    }

    public void setPrediction(Predictor.Result r, boolean cap, String extras,
                              List<String> suggestions, float boost, boolean showPct) {
        this.res = r;
        this.cap = cap;
        this.extras = extras == null ? "" : extras;
        this.boost = boost;
        this.showPct = showPct;
        for (int i = 0; i < 3; i++) sugWords[i] = i < suggestions.size() ? suggestions.get(i) : "";
        layout();
        invalidate();
    }

    public void setLayer(int l) {
        if (l == layer) return;
        cancelLongPress();
        panId = -1;
        clipOffset = 0f;
        layer = l;
        layout();
        invalidate();
    }

    public void setLangs(Set<String> langs) {
        activeLangs = new HashSet<>(langs);
        List<String> sorted = new ArrayList<>(langs);
        java.util.Collections.sort(sorted);
        String key = sorted.toString();
        if (key.equals(langKey)) return;
        langKey = key;
        ntilde = langs.contains("tl") || langs.contains("es");
        LinkedHashSet<Character> order = new LinkedHashSet<>();
        String[][] pri = {
                {"fr", "àâæçéèêëîïôœùûüÿ"}, {"es", "áéíóúüñ"}, {"pt", "áàâãçéêíóôõú"},
                {"de", "äöüß"}, {"tl", "ñ"}};
        for (String[] pl : pri) {
            if (!langs.contains(pl[0])) continue;
            for (char c : pl[1].toCharArray()) order.add(c);
        }
        for (char c : GENERAL_ACCENTS.toCharArray()) order.add(c);
        variantMap.clear();
        for (char c : order) {
            if (c == 'ñ' && ntilde) continue; // has its own key
            char b = baseOf(c);
            if (b < 'a' || b > 'z') continue;
            List<Character> l = variantMap.get(b);
            if (l == null) { l = new ArrayList<>(); variantMap.put(b, l); }
            l.add(c);
        }
    }

    private static char baseOf(char c) {
        switch (c) {
            case 'æ': return 'a';
            case 'œ': return 'o';
            case 'ø': return 'o';
            case 'ß': return 's';
            case 'ł': return 'l';
            case 'ð': return 'd';
            default:
                String d = Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD);
                return d.charAt(0);
        }
    }

    private float dp(float v) { return v * density; }

    private static int blend(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar * t + br * (1 - t));
        int g = Math.round(ag * t + bg * (1 - t));
        int bl = Math.round(ab * t + bb * (1 - t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    private float pOf(char c) {
        if (res == null) return 0f;
        int i = c == 'ñ' ? 26 : c - 'a';
        return (i >= 0 && i < 27) ? res.p[i] : 0f;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, Math.round(dp(42 + 4 + 300)));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layout();
    }

    private void layout() {
        keys.clear();
        float W = getWidth(), H = getHeight();
        if (W == 0 || H == 0) return;
        float gap = dp(4), sug = dp(42);
        float toolW = dp(38);
        for (int i = 0; i < 2; i++) {
            toolRects[i].set(i * (toolW + gap), 0, i * (toolW + gap) + toolW, sug);
        }
        float x0 = 2 * (toolW + gap);
        float cellW = (W - x0 - 2 * gap) / 3f;
        for (int i = 0; i < 3; i++) {
            sugRects[i].set(x0 + i * (cellW + gap), 0, x0 + i * (cellW + gap) + cellW, sug);
        }
        titleRect.set(x0, 0, W, sug);
        if (layer >= 3) {
            layoutPanel(W, H, gap, sug);
            return;
        }

        String[] rows;
        if (layer == 0) rows = new String[]{"qwertyuiop", "asdfghjkl" + extras, "zxcvbnm"};
        else if (layer == 1) rows = new String[]{"1234567890", "@#$_&-+()/", "*\"':;!?"};
        else rows = new String[]{"~`|•√π÷×¶\\", "£€¥¢°=<>{}", "©®™¿¡[]"};
        List<List<Key>> rowKeys = new ArrayList<>();
        float[] rowMax = new float[4];
        for (int ri = 0; ri < 3; ri++) {
            List<Key> list = new ArrayList<>();
            if (ri == 2 && layer > 0) {
                Key alt = new Key();
                alt.type = T_ALT; alt.weight = 1.7f;
                list.add(alt);
            } else if (ri == 2) {
                Key sh = new Key();
                sh.type = T_SHIFT; sh.weight = 1.7f;
                list.add(sh);
            }
            for (char c : rows[ri].toCharArray()) {
                Key k = new Key();
                k.ch = c;
                if (layer == 0) {
                    k.type = T_LETTER; k.p = pOf(c); k.tint = tintOf(c);
                    k.weight = 1f + 8f * boost * (float) Math.sqrt(k.p);
                    rowMax[ri] = Math.max(rowMax[ri], k.p);
                } else {
                    k.type = T_CHAR; k.weight = 1f;
                }
                list.add(k);
            }
            if (ri == 2) {
                Key bs = new Key();
                bs.type = T_BS; bs.weight = 1.7f;
                list.add(bs);
            }
            rowKeys.add(list);
        }
        float pEnd = (layer == 0 && res != null) ? res.pEnd : 0f;
        rowMax[3] = pEnd;
        List<Key> bottom = new ArrayList<>();
        int[] types = {layer == 0 ? T_SYM : T_ABC, T_COMMA, T_SPACE, T_DOT, T_ENTER};
        for (int t : types) {
            Key k = new Key();
            k.type = t;
            if (t == T_SPACE) {
                k.weight = 5f + 9f * boost * (float) Math.sqrt(pEnd);
                k.p = pEnd;
            } else if (t == T_SYM || t == T_ABC) {
                k.weight = 1.7f;
            } else {
                k.weight = 1.4f;
            }
            bottom.add(k);
        }
        rowKeys.add(bottom);

        float[] rw = new float[4];
        float sum = 0;
        for (int i = 0; i < 4; i++) {
            rw[i] = 1f + 1.5f * boost * (float) Math.sqrt(rowMax[i]);
            sum += rw[i];
        }
        float top = sug + gap;
        float avail = H - top - 3 * gap;
        float y = top;
        for (int ri = 0; ri < 4; ri++) {
            float rh = avail * rw[ri] / sum;
            List<Key> list = rowKeys.get(ri);
            float indent = (ri == 1 && rows[1].length() < 10) ? W * 0.04f : 0f;
            float rowW = W - 2 * indent - gap * (list.size() - 1);
            float wsum = 0;
            for (Key k : list) wsum += k.weight;
            float x = indent;
            for (Key k : list) {
                float kw = rowW * k.weight / wsum;
                k.r.set(x, y, x + kw, y + rh);
                x += kw + gap;
                keys.add(k);
            }
            y += rh + gap;
        }
    }

    private void layoutPanel(float W, float H, float gap, float sug) {
        float bottomH = dp(50);
        content.set(0, sug + gap, W, H - bottomH - gap);
        int[] types;
        float[] ws;
        if (layer == 3) {
            types = new int[]{T_ABC, T_CLEAR, T_BS, T_ENTER};
            ws = new float[]{1.7f, 2f, 1.4f, 1.4f};
        } else {
            types = new int[]{T_ABC, T_SPACE, T_ENTER};
            ws = new float[]{1.7f, 5f, 1.7f};
        }
        float wsum = 0;
        for (float w : ws) wsum += w;
        float rowW = W - gap * (types.length - 1);
        float x = 0, y = H - bottomH;
        for (int i = 0; i < types.length; i++) {
            Key k = new Key();
            k.type = types[i];
            k.weight = ws[i];
            float kw = rowW * ws[i] / wsum;
            k.r.set(x, y, x + kw, y + bottomH);
            x += kw + gap;
            keys.add(k);
        }
        if (layer == 4) {
            float cw = (W - gap) / 2f;
            float chh = (content.height() - 3 * gap) / 4f;
            for (int i = 0; i < LANGS.length; i++) {
                Key k = new Key();
                k.type = T_LANG;
                k.code = LANGS[i][0];
                k.label = LANGS[i][1];
                float lx = (i % 2) * (cw + gap);
                float ly = content.top + (i / 2) * (chh + gap);
                k.r.set(lx, ly, lx + cw, ly + chh);
                keys.add(k);
            }
        }
    }

    private float maxClipOffset() {
        return Math.max(0f, clips.size() * dp(48) - content.height());
    }

    private void drawExtras(Canvas canvas, float radius) {
        String[] icons = {"📋", "🌐"};
        for (int i = 0; i < 2; i++) {
            boolean on = (i == 0 && layer == 3) || (i == 1 && layer == 4);
            fill.setColor(on ? cHot : cPanel);
            canvas.drawRoundRect(toolRects[i], radius, radius, fill);
            text.setColor(on ? cHotFg : cFg);
            text.setTextSize(dp(18));
            drawCentered(canvas, icons[i], toolRects[i].centerX(), toolRects[i].centerY());
        }
        if (layer < 3) return;
        fill.setColor(cPanel);
        canvas.drawRoundRect(titleRect, radius, radius, fill);
        text.setColor(cFg);
        text.setTextSize(dp(15));
        drawCentered(canvas, layer == 3 ? "Clipboard" : "Languages (tap to toggle)",
                titleRect.centerX(), titleRect.centerY());
        if (layer != 3) return;

        canvas.save();
        canvas.clipRect(content);
        if (clips.isEmpty()) {
            String msg = clipEnabled ? "Nothing copied yet" : "History is off (enable it in app settings)";
            text.setColor(cFg);
            float size = dp(14);
            text.setTextSize(size);
            float tw = text.measureText(msg);
            float maxW = content.width() - dp(24);
            if (tw > maxW) text.setTextSize(size * maxW / tw);
            drawCentered(canvas, msg, content.centerX(), content.centerY());
        }
        float step = dp(48), rh = dp(44);
        for (int i = 0; i < clips.size(); i++) {
            float top = content.top + i * step - clipOffset;
            if (top + rh < content.top || top > content.bottom) continue;
            rowRect.set(0, top, content.right, top + rh);
            fill.setColor(cKey);
            canvas.drawRoundRect(rowRect, radius, radius, fill);
            String str = clips.get(i).replaceAll("\\s+", " ");
            text.setColor(cFg);
            text.setTextSize(dp(14));
            float maxW = rowRect.width() - dp(12) - dp(44);
            int n = text.breakText(str, true, maxW, null);
            if (n < str.length()) str = str.substring(0, Math.max(0, n - 1)) + "…";
            text.setTextAlign(Paint.Align.LEFT);
            Paint.FontMetrics fm = text.getFontMetrics();
            canvas.drawText(str, dp(12), rowRect.centerY() - (fm.ascent + fm.descent) / 2f, text);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(dp(18));
            drawCentered(canvas, "×", rowRect.right - dp(22), rowRect.centerY());
        }
        canvas.restore();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(cBg);
        float radius = dp(8);

        // suggestions
        for (int i = 0; layer < 3 && i < 3; i++) {
            RectF r = sugRects[i];
            fill.setColor(cPanel);
            canvas.drawRoundRect(r, radius, radius, fill);
            String s = sugWords[i];
            if (s.isEmpty()) continue;
            if (shiftMode == 2) s = s.toUpperCase();
            int tint = sugTint(i);
            if (tint != 0) {
                fill.setColor(blend(tint, cPanel, 0.28f));
                canvas.drawRoundRect(r, radius, radius, fill);
                fill.setColor(tint);
                rowRect.set(r.left + dp(10), r.bottom - dp(4), r.right - dp(10), r.bottom - dp(1.5f));
                canvas.drawRoundRect(rowRect, dp(2), dp(2), fill);
            }
            text.setColor(cFg);
            float size = dp(16);
            text.setTextSize(size);
            float tw = text.measureText(s);
            float maxW = r.width() - dp(12);
            if (tw > maxW) text.setTextSize(size * maxW / tw);
            drawCentered(canvas, s, r.centerX(), r.centerY());
        }

        drawExtras(canvas, radius);

        for (Key k : keys) {
            float s = (float) Math.sqrt(k.p);
            float heat = Math.min(1f, s * 1.25f * Math.min(boost, 1f));
            boolean hot = s > 0.55f && boost > 0f;
            int hotC = (k.type == T_LETTER && k.tint != 0) ? k.tint : cHot;
            int bg;
            if (k.type == T_LETTER || k.type == T_SPACE || k.type == T_CHAR) bg = blend(hotC, cKey, heat);
            else bg = cFn;
            boolean langOn = k.type == T_LANG && activeLangs.contains(k.code);
            int chipC = langColorOf(k.code);
            if (k.type == T_LANG) bg = langOn ? chipC : cKey;
            boolean shiftOn = k.type == T_SHIFT && (shiftMode == 1 || shiftMode == 2);
            if (k.type == T_SHIFT) {
                bg = shiftOn ? cHot : (shiftMode == 0 && cap ? blend(cHot, cFn, 0.35f) : cFn);
            }
            if (k == pressed) bg = blend(cHot, bg, 0.35f);
            fill.setColor(bg);
            RectF r = k.r;
            canvas.drawRoundRect(r, radius, radius, fill);
            int fg = hot ? Theme.onColor(hotC) : cFg;
            if (langOn) fg = Theme.onColor(chipC);
            if (shiftOn) fg = cHotFg;
            text.setColor(fg);

            switch (k.type) {
                case T_LETTER: {
                    String label = String.valueOf(isUpper() ? Character.toUpperCase(k.ch) : k.ch);
                    float size = dp(15f + 15f * boost * s);
                    size = Math.min(size, r.height() * 0.6f);
                    text.setTextSize(size);
                    boolean pct = showPct && k.p >= 0.05f;
                    float cy = pct ? r.centerY() - dp(5) : r.centerY();
                    drawCentered(canvas, label, r.centerX(), cy);
                    if (pct) {
                        text.setTextSize(dp(10));
                        drawCentered(canvas, Math.round(k.p * 100) + "%", r.centerX(), r.centerY() + size * 0.45f + dp(4));
                    }
                    break;
                }
                case T_LANG:
                    text.setTextSize(dp(16));
                    drawCentered(canvas, (langOn ? "✓ " : "") + k.label, r.centerX(), r.centerY());
                    if (!langOn) {
                        fill.setColor(chipC);
                        canvas.drawCircle(r.left + dp(16), r.centerY(), dp(6), fill);
                    }
                    break;
                case T_SHIFT:
                    text.setTextSize(dp(22));
                    drawCentered(canvas, "⇧", r.centerX(), r.centerY() - (shiftMode == 2 ? dp(3) : 0));
                    if (shiftMode == 2) {
                        fill.setColor(fg);
                        rowRect.set(r.centerX() - dp(8), r.centerY() + dp(11), r.centerX() + dp(8), r.centerY() + dp(13.5f));
                        canvas.drawRoundRect(rowRect, dp(1), dp(1), fill);
                    }
                    break;
                case T_CLEAR:
                    text.setTextSize(dp(13));
                    drawCentered(canvas, "Clear all", r.centerX(), r.centerY());
                    break;
                case T_CHAR:
                    text.setTextSize(Math.min(dp(20), r.height() * 0.6f));
                    drawCentered(canvas, String.valueOf(k.ch), r.centerX(), r.centerY());
                    break;
                case T_SYM:
                    text.setTextSize(dp(14));
                    drawCentered(canvas, "?123", r.centerX(), r.centerY());
                    break;
                case T_ABC:
                    text.setTextSize(dp(14));
                    drawCentered(canvas, "ABC", r.centerX(), r.centerY());
                    break;
                case T_ALT:
                    text.setTextSize(dp(14));
                    drawCentered(canvas, layer == 1 ? "=\\<" : "?123", r.centerX(), r.centerY());
                    break;
                case T_SPACE:
                    text.setTextSize(dp(13));
                    drawCentered(canvas, "space", r.centerX(), r.centerY());
                    break;
                case T_BS:
                    text.setTextSize(dp(18));
                    drawCentered(canvas, "⌫", r.centerX(), r.centerY());
                    break;
                case T_COMMA:
                    text.setTextSize(dp(18));
                    drawCentered(canvas, ",", r.centerX(), r.centerY());
                    break;
                case T_DOT:
                    text.setTextSize(dp(18));
                    drawCentered(canvas, ".", r.centerX(), r.centerY());
                    break;
                default:
                    text.setTextSize(dp(18));
                    drawCentered(canvas, "⏎", r.centerX(), r.centerY());
            }
        }

        if (popShown) {
            fill.setColor(cPanel);
            canvas.drawRoundRect(popPanel, radius, radius, fill);
            canvas.drawRoundRect(popPanel, radius, radius, stroke);
            for (int i = 0; i < popRects.length; i++) {
                RectF r = popRects[i];
                if (i == popSel) {
                    fill.setColor(cHot);
                    canvas.drawRoundRect(r, radius, radius, fill);
                    text.setColor(cHotFg);
                } else {
                    text.setColor(cFg);
                }
                text.setTextSize(dp(22));
                drawCentered(canvas, popVariants[i], r.centerX(), r.centerY());
            }
        }
    }

    private void drawCentered(Canvas c, String s, float cx, float cy) {
        Paint.FontMetrics fm = text.getFontMetrics();
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, text);
    }

    // ---- touch ----

    private final Runnable repeatBs = new Runnable() {
        @Override public void run() {
            if (listener != null) listener.onBackspace();
            handler.postDelayed(this, 70);
        }
    };

    private final Runnable clearPress = new Runnable() {
        @Override public void run() { pressed = null; invalidate(); }
    };

    private Key hit(float x, float y) {
        float slop = dp(2);
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Key k : keys) {
            RectF r = k.r;
            if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) {
                float dx = x - r.centerX(), dy = y - r.centerY();
                float d = dx * dx + dy * dy;
                if (d < bestD) { bestD = d; best = k; }
            }
        }
        return best;
    }

    // ---- long-press accent picker ----

    private final Runnable showPopup = new Runnable() {
        @Override public void run() {
            if (!lpActive) return;
            List<Character> vs = variantMap.get(lpChar);
            if (vs == null || vs.isEmpty()) return;
            Key anchor = null;
            for (Key k : keys) if (k.type == T_LETTER && k.ch == lpChar) { anchor = k; break; }
            if (anchor == null) return;
            int n = vs.size();
            float W = getWidth(), pad = dp(4);
            float cw = Math.min(dp(40), (W - 2 * pad) / n);
            float ch = dp(50);
            float total = n * cw;
            float left = anchor.r.centerX() - total / 2f;
            left = Math.max(pad, Math.min(W - pad - total, left));
            float top = Math.max(dp(2), anchor.r.top - ch - dp(8));
            popVariants = new String[n];
            popRects = new RectF[n];
            for (int i = 0; i < n; i++) {
                char c = vs.get(i);
                popVariants[i] = String.valueOf(lpCap ? Character.toUpperCase(c) : c);
                popRects[i] = new RectF(left + i * cw, top, left + (i + 1) * cw, top + ch);
            }
            popPanel.set(left - pad, top - pad, left + total + pad, top + ch + pad);
            popKeyTop = anchor.r.top;
            popSel = -1;
            popShown = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            invalidate();
        }
    };

    private void cancelLongPress() {
        handler.removeCallbacks(showPopup);
        boolean was = popShown;
        lpActive = false;
        popShown = false;
        popSel = -1;
        if (was) invalidate();
    }

    private void releaseLongPress(int pointerId) {
        if (!lpActive || pointerId != lpId) return;
        handler.removeCallbacks(showPopup);
        String pick = (popShown && popSel >= 0) ? popVariants[popSel] : null;
        lpActive = false;
        popShown = false;
        popSel = -1;
        invalidate();
        if (pick != null && listener != null) listener.onReplaceLast(pick);
    }

    private void moveLongPress(MotionEvent e) {
        if (!lpActive) return;
        int idx = e.findPointerIndex(lpId);
        if (idx < 0) return;
        float x = e.getX(idx), y = e.getY(idx);
        if (!popShown) {
            if (Math.abs(x - lpX) > dp(14) || Math.abs(y - lpY) > dp(14)) cancelLongPress();
            return;
        }
        int sel = -1;
        if (y < popKeyTop) {
            for (int i = 0; i < popRects.length; i++) {
                if (x >= popRects[i].left && x < popRects[i].right) { sel = i; break; }
            }
        }
        if (sel != popSel) {
            popSel = sel;
            invalidate();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int idx = e.getActionIndex();
                float tx = e.getX(idx), ty = e.getY(idx);
                if (layer == 3 && panId == -1 && content.contains(tx, ty)) {
                    cancelLongPress();
                    panId = e.getPointerId(idx);
                    panDownX = tx; panDownY = ty;
                    panStartOff = clipOffset;
                    panMoved = false;
                    return true;
                }
                press(tx, ty, e.getPointerId(idx));
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                moveLongPress(e);
                movePanel(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                releaseLongPress(e.getPointerId(e.getActionIndex()));
                releasePanel(e.getPointerId(e.getActionIndex()));
                handler.removeCallbacks(repeatBs);
                handler.removeCallbacks(clearPress);
                handler.postDelayed(clearPress, 60);
                return true;
            case MotionEvent.ACTION_CANCEL:
                cancelLongPress();
                panId = -1;
                handler.removeCallbacks(repeatBs);
                handler.removeCallbacks(clearPress);
                handler.postDelayed(clearPress, 60);
                return true;
            default:
                return true;
        }
    }

    private void movePanel(MotionEvent e) {
        if (panId == -1) return;
        int idx = e.findPointerIndex(panId);
        if (idx < 0) return;
        float dy = e.getY(idx) - panDownY;
        if (!panMoved && Math.abs(dy) > dp(8)) panMoved = true;
        if (panMoved) {
            clipOffset = Math.max(0f, Math.min(maxClipOffset(), panStartOff - dy));
            invalidate();
        }
    }

    private void releasePanel(int id) {
        if (panId == -1 || id != panId) return;
        panId = -1;
        if (!panMoved) tapClip(panDownX, panDownY);
    }

    private void tapClip(float x, float y) {
        float step = dp(48);
        float rel = y - content.top + clipOffset;
        int i = (int) Math.floor(rel / step);
        if (i < 0 || i >= clips.size() || rel - i * step > dp(44) || listener == null) return;
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (x > getWidth() - dp(48)) {
            listener.onDeleteClip(i);
        } else {
            String str = clips.get(i);
            setLayer(0);
            listener.onPasteClip(str);
        }
    }

    private void press(float x, float y, int pointerId) {
        if (listener == null) return;
        cancelLongPress();
        for (int i = 0; i < 2; i++) {
            if (toolRects[i].contains(x, y)) {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                int target = i == 0 ? 3 : 4;
                setLayer(layer == target ? 0 : target);
                return;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (layer < 3 && sugRects[i].contains(x, y)) {
                if (!sugWords[i].isEmpty()) {
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    listener.onSuggestion(shiftMode == 2 ? sugWords[i].toUpperCase() : sugWords[i]);
                }
                return;
            }
        }
        Key k = hit(x, y);
        if (k == null) return;
        pressed = k;
        invalidate();
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        switch (k.type) {
            case T_LETTER: {
                boolean up = isUpper();
                listener.onLetter(k.ch, up);
                if (shiftMode == 1 || shiftMode == 3) shiftMode = 0;
                List<Character> vs = variantMap.get(k.ch);
                if (vs != null && !vs.isEmpty()) {
                    lpActive = true;
                    lpChar = k.ch; lpId = pointerId; lpX = x; lpY = y; lpCap = up;
                    handler.postDelayed(showPopup, 380);
                }
                break;
            }
            case T_CHAR: listener.onChar(k.ch); break;
            case T_COMMA: listener.onChar(','); break;
            case T_DOT: listener.onChar('.'); break;
            case T_SPACE: listener.onChar(' '); break;
            case T_ENTER: listener.onChar('\n'); break;
            case T_SYM: setLayer(1); break;
            case T_ALT: setLayer(layer == 1 ? 2 : 1); break;
            case T_ABC: setLayer(0); break;
            case T_SHIFT: tapShift(); break;
            case T_LANG: listener.onToggleLang(k.code); break;
            case T_CLEAR: listener.onClearClips(); break;
            case T_BS:
                listener.onBackspace();
                handler.removeCallbacks(repeatBs);
                handler.postDelayed(repeatBs, 420);
                break;
            default: break;
        }
    }
}
