package com.fatfinger.keyboard;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Small clipboard history kept in the app's private preferences. Newest first. */
final class Clips {
    static final int MAX = 30;

    private Clips() { }

    static List<String> load(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString("clips", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (JSONException e) {
            // start empty
        }
        return out;
    }

    private static void save(SharedPreferences p, List<String> list) {
        JSONArray a = new JSONArray();
        for (String s : list) a.put(s);
        p.edit().putString("clips", a.toString()).apply();
    }

    static void add(SharedPreferences p, String s) {
        List<String> list = load(p);
        list.remove(s);
        list.add(0, s);
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(p, list);
    }

    static void remove(SharedPreferences p, int index) {
        List<String> list = load(p);
        if (index >= 0 && index < list.size()) {
            list.remove(index);
            save(p, list);
        }
    }

    static void clear(SharedPreferences p) {
        p.edit().remove("clips").apply();
    }
}
