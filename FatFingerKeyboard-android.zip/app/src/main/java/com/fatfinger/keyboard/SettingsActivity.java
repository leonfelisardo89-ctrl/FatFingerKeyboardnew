package com.fatfinger.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.HashSet;
import java.util.Set;

public class SettingsActivity extends Activity {

    private static final String[][] LANGS = {
            {"en", "English"}, {"tl", "Filipino"}, {"es", "Español"}, {"pt", "Português"},
            {"fr", "Français"}, {"de", "Deutsch"}, {"id", "Bahasa Indonesia"}
    };

    private SharedPreferences prefs;
    private LinearLayout preview;

    private GradientDrawable oval(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    private void refreshPreview() {
        Theme t = Theme.load(this, prefs);
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(t.bg);
        bgd.setCornerRadius(dp(12));
        preview.setBackground(bgd);
        preview.removeAllViews();
        String[] labels = {"Q", "W", "E", "R", "T"};
        for (int i = 0; i < labels.length; i++) {
            boolean hot = i == 2;
            TextView k = new TextView(this);
            k.setText(labels[i]);
            k.setGravity(Gravity.CENTER);
            k.setTextSize(hot ? 22 : 16);
            k.setTypeface(Typeface.DEFAULT_BOLD);
            k.setTextColor(hot ? t.hotFg : t.fg);
            GradientDrawable d = new GradientDrawable();
            d.setCornerRadius(dp(8));
            d.setColor(hot ? t.hot : t.key);
            k.setBackground(d);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), hot ? 1.8f : 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            preview.addView(k, lp);
        }
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView label(String s, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(bold ? 18 : 14);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(12), 0, dp(4));
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("fatfinger", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("FatFinger Keyboard");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);
        root.addView(label("Likely next letters grow. Unlikely ones shrink.", false));

        root.addView(label("1. Turn it on", true));
        Button enable = new Button(this);
        enable.setText("Open keyboard settings");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        root.addView(label("2. Switch to it", true));
        Button pick = new Button(this);
        pick.setText("Choose keyboard");
        pick.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(pick);

        root.addView(label("Languages (turn on several to blend them)", true));
        root.addView(label("You can also switch these live with the \uD83C\uDF10 button on the keyboard.", false));
        Set<String> saved = prefs.getStringSet("langs", null);
        final Set<String> active = new HashSet<>();
        if (saved == null || saved.isEmpty()) active.add("en"); else active.addAll(saved);
        for (String[] l : LANGS) {
            final String code = l[0];
            CheckBox cb = new CheckBox(this);
            cb.setText(l[1]);
            cb.setChecked(active.contains(code));
            cb.setOnCheckedChangeListener((btn, on) -> {
                if (on) active.add(code); else active.remove(code);
                if (active.isEmpty()) { active.add("en"); }
                prefs.edit().putStringSet("langs", new HashSet<>(active)).apply();
            });
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(cb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final View colorDot = new View(this);
            colorDot.setBackground(oval(Theme.langColor(prefs, code)));
            colorDot.setOnClickListener(x -> {
                int cur = Theme.langColor(prefs, code);
                int next = Theme.ACCENTS[0];
                for (int j = 0; j < Theme.ACCENTS.length; j++) {
                    if (Theme.ACCENTS[j] == cur) {
                        next = Theme.ACCENTS[(j + 1) % Theme.ACCENTS.length];
                        break;
                    }
                }
                prefs.edit().putInt("lc_" + code, next).apply();
                colorDot.setBackground(oval(next));
            });
            row.addView(colorDot, new LinearLayout.LayoutParams(dp(32), dp(32)));
            root.addView(row);
        }

        CheckBox colorCb = new CheckBox(this);
        colorCb.setText("Color keys and suggestions by language (tap a dot above to change its color)");
        colorCb.setChecked(prefs.getBoolean("langColor", true));
        colorCb.setOnCheckedChangeListener((btn, on) -> prefs.edit().putBoolean("langColor", on).apply());
        root.addView(colorCb);

        root.addView(label("Theme", true));
        preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.HORIZONTAL);
        preview.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.addView(preview);
        RadioGroup rg = new RadioGroup(this);
        String curTheme = prefs.getString("theme", "auto");
        int checkId = 1000;
        for (int i = 0; i < Theme.IDS.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(Theme.NAMES[i]);
            rb.setId(1000 + i);
            rg.addView(rb);
            if (Theme.IDS[i].equals(curTheme)) checkId = 1000 + i;
        }
        rg.check(checkId);
        rg.setOnCheckedChangeListener((g, id) -> {
            prefs.edit().putString("theme", Theme.IDS[id - 1000]).apply();
            refreshPreview();
        });
        root.addView(rg);

        root.addView(label("Accent color", true));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout sw = new LinearLayout(this);
        sw.setOrientation(LinearLayout.HORIZONTAL);
        for (final int col : Theme.ACCENTS) {
            View dot = new View(this);
            GradientDrawable od = new GradientDrawable();
            od.setShape(GradientDrawable.OVAL);
            od.setColor(col);
            dot.setBackground(od);
            dot.setOnClickListener(x -> {
                prefs.edit().putInt("accent", col).apply();
                refreshPreview();
            });
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(40), dp(40));
            dlp.setMargins(0, dp(4), dp(10), dp(4));
            sw.addView(dot, dlp);
        }
        hs.addView(sw);
        root.addView(hs);
        Button defAccent = new Button(this);
        defAccent.setText("Use the theme's own accent");
        defAccent.setOnClickListener(v -> {
            prefs.edit().remove("accent").apply();
            refreshPreview();
        });
        root.addView(defAccent);
        final EditText hex = new EditText(this);
        hex.setHint("Custom accent, e.g. #1C7ED6");
        hex.setSingleLine(true);
        root.addView(hex);
        Button hexBtn = new Button(this);
        hexBtn.setText("Apply custom accent");
        hexBtn.setOnClickListener(v -> {
            String h = hex.getText().toString().trim();
            if (!h.startsWith("#")) h = "#" + h;
            try {
                int parsed = Color.parseColor(h);
                prefs.edit().putInt("accent", 0xFF000000 | (parsed & 0xFFFFFF)).apply();
                refreshPreview();
            } catch (IllegalArgumentException ex) {
                hex.setError("Use a color like #1C7ED6");
            }
        });
        root.addView(hexBtn);

        root.addView(label("Clipboard", true));
        root.addView(label("Open it with the \uD83D\uDCCB button on the keyboard. Copied text is kept on this phone only, and only while FatFinger is your active keyboard.", false));
        CheckBox clipCb = new CheckBox(this);
        clipCb.setText("Save clipboard history");
        clipCb.setChecked(prefs.getBoolean("clipOn", true));
        clipCb.setOnCheckedChangeListener((btn, on) -> prefs.edit().putBoolean("clipOn", on).apply());
        root.addView(clipCb);
        Button clipClear = new Button(this);
        clipClear.setText("Clear clipboard history");
        clipClear.setOnClickListener(v -> Clips.clear(prefs));
        root.addView(clipClear);

        root.addView(label("Key growth", true));
        SeekBar sb = new SeekBar(this);
        sb.setMax(160);
        sb.setProgress(Math.round(prefs.getFloat("boost", 1f) * 100));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                prefs.edit().putFloat("boost", p / 100f).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(sb);

        CheckBox pct = new CheckBox(this);
        pct.setText("Show percentages on keys");
        pct.setChecked(prefs.getBoolean("showPct", true));
        pct.setOnCheckedChangeListener((btn, on) -> prefs.edit().putBoolean("showPct", on).apply());
        root.addView(pct);

        Button forget = new Button(this);
        forget.setText("Forget learned words");
        forget.setOnClickListener(v -> new Predictor(this).forgetAll());
        root.addView(forget);

        root.addView(label("Try it here", true));
        EditText test = new EditText(this);
        test.setHint("Tap and type");
        test.setMinLines(3);
        root.addView(test);

        refreshPreview();
        setContentView(sv);
    }
}
