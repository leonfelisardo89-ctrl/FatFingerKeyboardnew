# FatFinger Keyboard (Android)

A keyboard whose keys grow with the chance that letter comes next. Supports English, Filipino,
Spanish, Portuguese, French, German and Indonesian, and several can be active at once.

## Numbers, symbols and accents

- **?123** (bottom-left) switches to numbers and common symbols; **=\<** there opens a second page
  (currency, brackets, math, copyright signs, ¿ ¡). **ABC** returns to letters. Number, phone and
  date fields open on the numbers page automatically.
- **Accented letters:** hold a letter (a, e, i, o, u, c, n, s, y, z, l, d), then slide up onto the
  accent you want and release. Accents for your active languages are listed first. Releasing without
  sliding keeps the plain letter.

## Shift, caps lock and language colors

- **⇧** (left of Z): tap once for one capital letter, double-tap for caps lock (shown with an
  underline), tap again to go back to lowercase. At the start of a sentence it auto-capitalizes;
  tapping ⇧ then forces a lowercase letter. Suggestions turn ALL CAPS in caps lock.
- **Language colors:** keys and word suggestions take the color of the language that contributes most
  to them, so with English and Filipino on, English-leaning letters are blue and Filipino-leaning ones
  green. Key brightness still shows how likely the letter is. Tap the colored dot next to a language
  in the app settings to change its color, or untick "Color keys and suggestions by language".

## Clipboard, languages and themes

- **📋 (top-left of the keyboard):** clipboard history. Tap an entry to paste it, × removes it,
  **Clear all** empties the list, drag to scroll. It records copies only while FatFinger is your
  active keyboard, stays on the phone, and skips clips Android marks as sensitive. Turn it off in
  the app settings.
- **🌐:** turn languages on or off live, without opening the app.
- **Themes:** open the FatFinger Keyboard app for Match system, Light, Dark, Midnight, Forest, Ocean,
  Rose and Lavender, plus accent swatches or a custom #RRGGBB accent. The keyboard picks up changes
  the next time it opens.

## Build the APK

**Android Studio:** open this folder, let Gradle sync, then Build > Build APK(s).
Output: `app/build/outputs/apk/debug/app-debug.apk`

**GitHub:** push this folder to a repo. The workflow in `.github/workflows/build-apk.yml` builds the
APK on every push. Download it from the run's Artifacts (`FatFingerKeyboard-apk`).

**Command line** (Android SDK and Gradle 8.9+ installed): `gradle assembleDebug`

## Install

Copy the APK to your phone and open it (allow "install unknown apps" if asked). Open the
FatFinger Keyboard app, tap "Open keyboard settings", enable the keyboard, then "Choose keyboard".
